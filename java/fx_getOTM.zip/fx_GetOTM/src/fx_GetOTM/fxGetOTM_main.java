package fx_GetOTM;

import java.io.IOException;

import fx_GetOTM.model.ListeOfficiels;
import fx_GetOTM.view.ListeOfficielsOverviewController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
//import javafx.stage.Stage;
//import java.time.LocalDate;
//import java.time.format.DateTimeFormatter;



public class fxGetOTM_main extends Application {
    private static Stage primaryStage;
    private BorderPane rootLayout;

    private ObservableList<ListeOfficiels> listeOfficielsData = FXCollections.observableArrayList();
    
	@Override
	public void start(Stage primaryStage) {
        fxGetOTM_main.primaryStage = primaryStage;
        fxGetOTM_main.primaryStage.setTitle("Recherche OTM/Arbitre Club");

        /******
         * donnees de test a supprimer

        listeOfficielsData.add(new ListeOfficiels("Villain1","Pierre1","OTM Club en formation","2018/10/18"));
        listeOfficielsData.add(new ListeOfficiels("Villain2","Pierre2","OTM Club en formation","2018/10/19"));
        listeOfficielsData.add(new ListeOfficiels("Villain3","Pierre3","OTM Club en formation","2018/10/20"));
        listeOfficielsData.add(new ListeOfficiels("Villain4","Pierre4","OTM Club en formation","2018/10/21"));
        listeOfficielsData.add(new ListeOfficiels("Villain5","Pierre5","OTM Club en formation","2018/10/22"));
        listeOfficielsData.add(new ListeOfficiels("Villain6","Pierre6","OTM Club en formation","2018/10/23"));
        listeOfficielsData.add(new ListeOfficiels("Villain7","Pierre7","OTM Club en formation","2018/10/24"));
        listeOfficielsData.add(new ListeOfficiels("Villain8","Pierre8","OTM Club en formation","2018/10/25"));
        listeOfficielsData.add(new ListeOfficiels("Villain9","Pierre9","OTM Club en formation","2018/10/26"));
        listeOfficielsData.add(new ListeOfficiels("Villain0","Pierre0","OTM Club en formation","2018/10/27"));
        */      
        initRootLayout();
        showOverview();
	}
    /**
     * Returns the data as an observable list. 
     * @return
     */
    public ObservableList<ListeOfficiels> getListeOfficielsData() {
        return listeOfficielsData;
    }
    /**x
     * Initializes the root layout.
     */
    public void initRootLayout() {
        try {
            // Load root layout from fxml file.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(fxGetOTM_main.class.getResource("view/RootLayout.fxml"));
            rootLayout = (BorderPane) loader.load();
            
            // Show the scene containing the root layout.
            Scene scene = new Scene(rootLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Shows the person overview inside the root layout.
     */
    public void showOverview() {
        try {
            // Load  overview.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(fxGetOTM_main.class.getResource("view/fx_GetOTM_Frame.fxml"));
            AnchorPane Overview = (AnchorPane) loader.load();
            
            // Set overview into the center of root layout.
            rootLayout.setCenter(Overview);
            
            // Give the controller access to the main app.
            ListeOfficielsOverviewController controller = loader.getController();
            controller.setfxGetOTM_main(this);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Returns the main stage.
     * @return
     */
    public static Stage getPrimaryStage() {
        return primaryStage;
    }
    
	public static void main(String[] args) {
		launch(args);
	}
}
