package fx_GetOTM.model;

//import javafx.beans.property.ObjectProperty;
import javafx.beans.property.StringProperty;
//import javafx.fxml.FXML;
//import javafx.scene.control.Label;
//import javafx.scene.control.TableColumn;
//import javafx.scene.control.TableView;
//import javafx.stage.DirectoryChooser;
//import javafx.stage.FileChooser;

//import java.io.File;
//import java.time.LocalDate;

//import fx_GetOTM.fxGetOTM_main;
//import fx_GetOTM.model.ListeOfficiels;


public class EcranHaut {
	//private final StringProperty inDirLabel;
	private StringProperty inDirValue;
	//private final StringProperty inDirBtn;
	//private final StringProperty outFileLabel;
	private StringProperty outFileValue;
	//private final StringProperty outFileBtn;
	//private final StringProperty runBtn;

	public EcranHaut() {
		this.inDirValue.set("");
		this.outFileValue.set("");
	}
	
	public String getInDirValue() {
		return inDirValue.get();
	}
	public String getOutFileValue() {
		return outFileValue.get();
	}
	public void setInDirValue(String data) {
		this.inDirValue.set(data);
	}
	public void setOutFileValue(String data) {
		this.outFileValue.set(data);
	}
    public StringProperty inDirValueProperty() {
        return inDirValue;
    }
    public StringProperty outFileValueProperty() {
        return outFileValue;
    }
}
