package fx_GetOTM.view;

//import javafx.beans.property.ObjectProperty;
//import javafx.beans.property.StringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
//import javafx.scene.control.TableColumn;
//import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
//import javafx.scene.layout.GridPane;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;

import java.io.File;
//import java.time.LocalDate;

import fx_GetOTM.fxGetOTM_main;
//import fx_GetOTM.model.ListeOfficiels;
//import fx_GetOTM.model.EcranHaut;

public class EcranHautController {

	    @FXML
	    private Label inDirLabel;
	    @FXML
	    private TextField inDirValue;
	    @FXML
	    private Button inDirBtn;
	    @FXML
	    private Label outFileLabel;
	    @FXML
	    private TextField outFileValue;
	    @FXML
	    private Button outFileBtn;
	    @FXML
	    private Button runBtn;
	   
	    /**
	     * The constructor.
	     * The constructor is called before the initialize() method.
	     */
	    public EcranHautController() {
	    }
	    /*
	    private void dirChooser() {
	    	final DirectoryChooser searchDir = new DirectoryChooser();
		  
	    	if (getInDirValue() != null) {
	    		searchDir.setInitialDirectory(new File(getInDirValue()));
	    	}
	    	else {
	    		searchDir.setInitialDirectory(new File(System.getProperty("user.home")));
	    	}
	    	
	    	File selectedDirectory = searchDir.showDialog(fxGetOTM_main.getPrimaryStage());
	    	if (selectedDirectory != null) {
	    		setInDirValue(selectedDirectory.getAbsolutePath());
	    	}
	    }
	    @FXML
	    private void outChooser() {
	    	final FileChooser fileChooser = new FileChooser();
	    	if (getOutFileValue() != null) {
	    		fileChooser.setInitialDirectory(new File(getOutFileValue()));
	    	}
	    	else {
	    		fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
	    	}
	    	final File selectedFile = fileChooser.showOpenDialog(fxGetOTM_main.getPrimaryStage());
	    	if (selectedFile != null) {
	    		setOutFileValue(selectedFile.getAbsolutePath());
	    	}
	    }
	    */
	    @FXML
	    private void dirChooser() {
	    	final DirectoryChooser searchDir = new DirectoryChooser();
		  
	    	/*if (EcranHaut.getInDirValue() != null) {
	    		searchDir.setInitialDirectory(new File(getInDirValue()));
	    	}
	    	else {
	    		searchDir.setInitialDirectory(new File(System.getProperty("user.home")));
	    	}*/
	    	
	    	File selectedDirectory = searchDir.showDialog(fxGetOTM_main.getPrimaryStage());
	    	if (selectedDirectory != null) {
	    		System.out.println("choix : "+selectedDirectory);
	    		//setInDirValue(selectedDirectory.getAbsolutePath());
	    	}
	    }
	    @FXML
	    private void outChooser() {
	    	final FileChooser fileChooser = new FileChooser();
	    	/*
	    	 * if (getOutFileValue() != null) {
	    		fileChooser.setInitialDirectory(new File(getOutFileValue()));
	    	}
	    	else {
	    		fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
	    	}
	    	*/
	    	final File selectedFile = fileChooser.showOpenDialog(fxGetOTM_main.getPrimaryStage());
	    	if (selectedFile != null) {
	    		System.out.println("choix : "+selectedFile);
	    		//setOutFileValue(selectedFile.getAbsolutePath());
	    	}
	    }
	}