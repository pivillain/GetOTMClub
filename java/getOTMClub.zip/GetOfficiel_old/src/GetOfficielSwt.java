import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.FlowLayout;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.BoxLayout;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JSeparator;
import java.awt.CardLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;

import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import com.jgoodies.forms.layout.FormSpecs;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Component;
import javax.swing.Box;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;
import javax.swing.border.BevelBorder;
import javax.swing.JScrollPane;
import javax.swing.border.LineBorder;

public class GetOfficielSwt {

	private Stage ecran;
	private JFrame frmRechercheOtmarbitreClub;
	private JTextField FBIDirectory;
	private JTextField OutputFile;
	private JTable tableResult;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GetOfficielSwt window = new GetOfficielSwt();
					window.frmRechercheOtmarbitreClub.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GetOfficielSwt() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		ecran=new Stage();
		frmRechercheOtmarbitreClub = new JFrame();
		frmRechercheOtmarbitreClub.setTitle("Recherche OTM/Arbitre Club");
		frmRechercheOtmarbitreClub.setBounds(100, 100, 450, 300);
		frmRechercheOtmarbitreClub.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmRechercheOtmarbitreClub.getContentPane().setLayout(new BoxLayout(frmRechercheOtmarbitreClub.getContentPane(), BoxLayout.X_AXIS));
		
		JPanel panel = new JPanel();
		frmRechercheOtmarbitreClub.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblFBIDir = new JLabel("R\u00E9pertoire export FBI");
		lblFBIDir.setBackground(new Color(204, 153, 255));
		lblFBIDir.setHorizontalAlignment(SwingConstants.CENTER);
		lblFBIDir.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblFBIDir.setBounds(0, 21, 105, 42);
		panel.add(lblFBIDir);
		
		FBIDirectory = new JTextField();
		FBIDirectory.setBounds(115, 21, 210, 42);
		FBIDirectory.setColumns(50);
		panel.add(FBIDirectory);
		
		JButton btnFBIDirectory = new JButton("Cherche");
		btnFBIDirectory.setFont(new Font("Tahoma", Font.PLAIN, 8));
		btnFBIDirectory.setForeground(Color.BLACK);
		btnFBIDirectory.setBounds(335, 21, 70, 42);
		panel.add(btnFBIDirectory);
		btnFBIDirectory.addActionListener(new ActionListener()
		{
			  public void actionPerformed(ActionEvent e)
			  {
			    	final DirectoryChooser searchDir = new DirectoryChooser();
			    	//GetOfficielSwt.ecran=ecran;
			    	if (FBIDirectory.getText() != null) {
			    		searchDir.setInitialDirectory(new File(FBIDirectory.getText()));
			    	}
			    	else {
			    		searchDir.setInitialDirectory(new File(System.getProperty("user.home")));
			    	}
			    
			    	File selectedDirectory = searchDir.showOpenDialog(ecran);
			    	if (selectedDirectory != null) {
			    		System.out.println("choix : "+selectedDirectory);
			    		FBIDirectory.setText(selectedDirectory.getAbsolutePath());
			    	}			  }
			});
		
		JLabel lblFichierRsultat = new JLabel("Fichier R\u00E9sultat");
		lblFichierRsultat.setBounds(10, 84, 105, 49);
		panel.add(lblFichierRsultat);
		
		OutputFile = new JTextField();
		OutputFile.setBounds(115, 87, 210, 42);
		panel.add(OutputFile);
		OutputFile.setColumns(10);
		
		JButton btnOutFile = new JButton("Cherche");
		btnOutFile.setFont(new Font("Tahoma", Font.PLAIN, 8));
		btnOutFile.setBounds(335, 87, 70, 42);
		panel.add(btnOutFile);
		btnOutFile.addActionListener(new ActionListener()
		{
			  public void actionPerformed(ActionEvent e)
			  {
			    	final FileChooser outFile = new FileChooser();
			    	if (OutputFile.getText() != null) {
			    		outFile.setInitialDirectory(new File(OutputFile.getText()));
			    	}
			    	else {
			    		outFile.setInitialDirectory(new File(System.getProperty("user.home")));
			    	}
			    
					final File selectedFile = outFile.showOpenDialog(ecran);
			    	if (selectedFile != null) {
			    		//System.out.println("choix : "+selectedFile);
			    		OutputFile.setText(selectedFile.getAbsolutePath());
			    	}
			  }
			});
		
		JButton btnCalcul = new JButton("Calcul");
		btnCalcul.setBounds(162, 140, 89, 23);
		panel.add(btnCalcul);
		
		tableResult = new JTable();
		tableResult.setBorder(new LineBorder(new Color(0, 0, 0)));
		tableResult.setBounds(0, 174, 434, 88);
		panel.add(tableResult);
	}
}
