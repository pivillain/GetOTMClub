package com.airfrance.qualif.gui;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.LoggerConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.airfrance.qualif.engine.GenerateScript;
import com.airfrance.qualif.engine.JMeterBench;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;

public class Application {

	private JFrame frmGnrationDeScript;
	private JTextField json_directory_textfield;
	private TextArea resultTextArea;
	private JTextField output_jmx_file_path_textfield;
	private JTextField scripts_directory_textfield;
	private JTextField load_textfield;

	static private String load = "average";
	private static String output_jmx_file_path = "";
	private static String json_directory = "";
	private static String scripts_directory = "";

	JButton btnNewButton;
	private GenerateScript engine = new GenerateScript();
	final static Logger logger = LoggerFactory.getLogger(Application.class);

	private static final String VER = "1.0.24";
	public static Options options = new Options();
	public static Option helpOption = new Option("help", "Print this message");
	public static Option debugOption = new Option("debug", "Active debug message");
	public static Option versionOption = new Option("version", "Print the version information and exit");
	public static Option scriptsOption = new Option("scripts", true, "Load JMeterTemplate and scripts from this directory path");
	public static Option inOption = new Option("in", true, "Load JSON data from this directory path");
	public static Option outOption = new Option("out", true, "Complete path and file name of the generate JMeter script");
	public static Option onlyErrorOption = new Option("onlyError", "Display only error on the log");
	public static Option loadOption = new Option("load", true,
			"Date of the load (optional) if not specify, average data are selected");

	/**
	 * Launch the application.
	 * @wbp.parser.entryPoint
	 */
	public void start(final String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					// Init cli option
					scriptsOption.setArgName("path to the directory which contain JMeterTempalte and scripts files");
					inOption.setArgName("path to the directory which contain json files");
					outOption.setArgName("example : /tmp/dallas_7.6.jtl");
					loadOption.setArgName("example : average nominale etc...");

					options.addOption(helpOption);
					options.addOption(versionOption);
					options.addOption(scriptsOption);
					options.addOption(inOption);
					options.addOption(outOption);
					options.addOption(loadOption);
					options.addOption(debugOption);
					options.addOption(onlyErrorOption);

					HelpFormatter formatter = new HelpFormatter();
					CommandLineParser parser = new DefaultParser();
					CommandLine cmd = null;

					LoggerContext ctx = (LoggerContext) LogManager.getContext(false);
					File file = new File("log4j2-generator.xml");
					ctx.setConfigLocation(file.toURI());
					Configuration config = ctx.getConfiguration();
					LoggerConfig loggerConfig = config.getLoggerConfig(LogManager.ROOT_LOGGER_NAME);

					loggerConfig.setLevel(Level.INFO);

					// start parsing option
					try {
						cmd = parser.parse(options, args);
					} catch (org.apache.commons.cli.ParseException e) {
						logger.error("Command parse error : " + e.getMessage());
						System.exit(0);
					}

					if (cmd.hasOption("onlyError")) {
						loggerConfig.setLevel(Level.ERROR);
					}

					if (cmd.hasOption("debug")) {
						loggerConfig.setLevel(Level.DEBUG);
					}

					ctx.updateLoggers();

					if (cmd.hasOption("help")) {
						formatter.printHelp("generateJMeterScriptFromJSON", options);
						System.exit(0);
					}
					if (cmd.hasOption("version")) {
						System.out.println("Version " + Application.VER);
						System.exit(0);
					}

					// Optionnal
					if (cmd.hasOption("load")) {
						load = cmd.getOptionValue("load");
					}
					
					Application app = new Application();

					if (cmd.hasOption("in") && cmd.hasOption("out") && cmd.hasOption("scripts")) {
						logger.info("Start no-gui mode");
						output_jmx_file_path = cmd.getOptionValue("out");
						json_directory = cmd.getOptionValue("in");
						scripts_directory = cmd.getOptionValue("scripts");
						int retCode = app.generate(scripts_directory, json_directory, output_jmx_file_path, load, true);
						System.exit(retCode);
					} else {
						// Gui mode
						app.initializeGUI();
						app.frmGnrationDeScript.setVisible(true);
					}

				} catch (Exception e) {
					logger.error(e.getMessage());
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @wbp.parser.entryPoint
	 */
	public Application() {

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initializeGUI() {
		frmGnrationDeScript = new JFrame();
		frmGnrationDeScript.setTitle("Generation of JMeter script (Version : " + VER + " JMeter : " + JMeterUtils.getJMeterVersion()+ ")");
		frmGnrationDeScript.setBounds(100, 100, 676, 480);
		frmGnrationDeScript.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{62, 28, 45, 21, 86, 15, 26, 59, 64, 1, 1, 75, 0};
		gridBagLayout.rowHeights = new int[]{17, 3, 67, 0, 0, 0, 0, 0, 0, 141, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
		frmGnrationDeScript.getContentPane().setLayout(gridBagLayout);
				
		//------------------------------------------------
		
		JSeparator separator = new JSeparator();
		GridBagConstraints gbc_separator = new GridBagConstraints();
		gbc_separator.anchor = GridBagConstraints.WEST;
		gbc_separator.insets = new Insets(0, 0, 5, 5);
		gbc_separator.gridx = 10;
		gbc_separator.gridy = 1;
		frmGnrationDeScript.getContentPane().add(separator, gbc_separator);
	    
	    JLabel lblTitle = new JLabel("JMX Generator !");
	    lblTitle.setFont(new Font("Segoe Print", Font.BOLD, 33));
	    GridBagConstraints gbc_lblTitle = new GridBagConstraints();
	    gbc_lblTitle.anchor = GridBagConstraints.NORTHWEST;
	    gbc_lblTitle.insets = new Insets(0, 0, 5, 5);
	    gbc_lblTitle.gridwidth = 6;
	    gbc_lblTitle.gridx = 3;
	    gbc_lblTitle.gridy = 2;
	    frmGnrationDeScript.getContentPane().add(lblTitle, gbc_lblTitle);
	    

	    JLabel lbl_1 = new JLabel("Application testcases folder :");
	    GridBagConstraints gbc_lbl_1 = new GridBagConstraints();
	    gbc_lbl_1.anchor = GridBagConstraints.WEST;
	    gbc_lbl_1.insets = new Insets(0, 0, 5, 5);
	    gbc_lbl_1.gridwidth = 3;
	    gbc_lbl_1.gridx = 1;
	    gbc_lbl_1.gridy = 3;
	    frmGnrationDeScript.getContentPane().add(lbl_1, gbc_lbl_1);		
	    
	    json_directory_textfield = new JTextField();
	    GridBagConstraints gbc_json_directory_textfield = new GridBagConstraints();
	    gbc_json_directory_textfield.fill = GridBagConstraints.BOTH;
	    gbc_json_directory_textfield.gridwidth = 5;
	    gbc_json_directory_textfield.insets = new Insets(0, 0, 5, 5);
	    gbc_json_directory_textfield.gridx = 4;
	    gbc_json_directory_textfield.gridy = 3;
	    frmGnrationDeScript.getContentPane().add(json_directory_textfield, gbc_json_directory_textfield);
	    json_directory_textfield.setColumns(10);
	    json_directory_textfield.setText("\\\\zma01tlsloadd\\Applis\\");
	    
	    		btnNewButton = new JButton("Start generation");
	    		btnNewButton.addActionListener(new ActionListener() {
	    			public void actionPerformed(ActionEvent arg0) {
	    				btnNewButton.setEnabled(false);
	    				generate(scripts_directory_textfield.getText(), json_directory_textfield.getText(), output_jmx_file_path_textfield.getText(), load_textfield.getText(), false);
	    				btnNewButton.setEnabled(true);
	    			}
	    		});
	    			
	    			JButton button_1 = new JButton("...");
	    			button_1.addActionListener(new ActionListener() {
	    				public void actionPerformed(ActionEvent e) {
	    					final JFileChooser fc = new JFileChooser();
	    					fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	    					File f = new File(json_directory_textfield.getText());
	    					fc.setCurrentDirectory(f);
	    					int returnVal = fc.showOpenDialog(frmGnrationDeScript);
	    					if (returnVal == JFileChooser.APPROVE_OPTION) {
	    						File file = fc.getSelectedFile();
	    						json_directory_textfield.setText(file.getPath());
	    					}

	    				}
	    			});
	    			GridBagConstraints gbc_button_1 = new GridBagConstraints();
	    			gbc_button_1.anchor = GridBagConstraints.NORTHWEST;
	    			gbc_button_1.insets = new Insets(0, 0, 5, 5);
	    			gbc_button_1.gridwidth = 2;
	    			gbc_button_1.gridx = 9;
	    			gbc_button_1.gridy = 3;
	    			frmGnrationDeScript.getContentPane().add(button_1, gbc_button_1);
	    		
	    		JLabel lbl_0 = new JLabel("Scripts & jmeter template folder :");
	    		GridBagConstraints gbc_lbl_0 = new GridBagConstraints();
	    		gbc_lbl_0.anchor = GridBagConstraints.WEST;
	    		gbc_lbl_0.insets = new Insets(0, 0, 5, 5);
	    		gbc_lbl_0.gridwidth = 3;
	    		gbc_lbl_0.gridx = 1;
	    		gbc_lbl_0.gridy = 4;
	    		frmGnrationDeScript.getContentPane().add(lbl_0, gbc_lbl_0);	
	    					
	    					scripts_directory_textfield = new JTextField();
	    					scripts_directory_textfield.setColumns(10);
	    					scripts_directory_textfield.setText("\\\\zma01tlsloadd\\Applis\\scripts-testcases");
	    					GridBagConstraints gbc_scripts_directory_textfield = new GridBagConstraints();
	    					gbc_scripts_directory_textfield.fill = GridBagConstraints.BOTH;
	    					gbc_scripts_directory_textfield.insets = new Insets(0, 0, 5, 5);
	    					gbc_scripts_directory_textfield.gridwidth = 5;
	    					gbc_scripts_directory_textfield.gridx = 4;
	    					gbc_scripts_directory_textfield.gridy = 4;
	    					frmGnrationDeScript.getContentPane().add(scripts_directory_textfield, gbc_scripts_directory_textfield);
	    				
	    				JButton button_0 = new JButton("...");
	    				button_0.addActionListener(new ActionListener() {
	    					public void actionPerformed(ActionEvent e) {
	    						final JFileChooser fc = new JFileChooser();
	    						fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	    						File f = new File(scripts_directory_textfield.getText());
	    						fc.setCurrentDirectory(f);
	    						int returnVal = fc.showOpenDialog(frmGnrationDeScript);
	    						if (returnVal == JFileChooser.APPROVE_OPTION) {
	    							File file = fc.getSelectedFile();
	    							scripts_directory_textfield.setText(file.getPath());
	    						}

	    					}
	    				});
	    				GridBagConstraints gbc_button_0 = new GridBagConstraints();
	    				gbc_button_0.anchor = GridBagConstraints.NORTHEAST;
	    				gbc_button_0.insets = new Insets(0, 0, 5, 5);
	    				gbc_button_0.gridx = 9;
	    				gbc_button_0.gridy = 4;
	    				frmGnrationDeScript.getContentPane().add(button_0, gbc_button_0);
	    				
	    				JLabel lbl_2 = new JLabel("Load name :");
	    				GridBagConstraints gbc_lbl_2 = new GridBagConstraints();
	    				gbc_lbl_2.gridwidth = 3;
	    				gbc_lbl_2.anchor = GridBagConstraints.WEST;
	    				gbc_lbl_2.insets = new Insets(0, 0, 5, 5);
	    				gbc_lbl_2.gridx = 1;
	    				gbc_lbl_2.gridy = 5;
	    				frmGnrationDeScript.getContentPane().add(lbl_2, gbc_lbl_2);	
	    				
	    				load_textfield  = new JTextField();
	    				load_textfield.setColumns(8);
	    				load_textfield.setText("average");
	    				GridBagConstraints gbc_load_textfield = new GridBagConstraints();
	    				gbc_load_textfield.fill = GridBagConstraints.BOTH;
	    				gbc_load_textfield.insets = new Insets(0, 0, 5, 5);
	    				gbc_load_textfield.gridwidth = 2;
	    				gbc_load_textfield.gridx = 4;
	    				gbc_load_textfield.gridy = 5;
	    				frmGnrationDeScript.getContentPane().add(load_textfield, gbc_load_textfield);
	    				
		JLabel lblFichierDeSortie = new JLabel("Output file :");
		GridBagConstraints gbc_lblFichierDeSortie = new GridBagConstraints();
		gbc_lblFichierDeSortie.fill = GridBagConstraints.HORIZONTAL;
		gbc_lblFichierDeSortie.gridwidth = 3;
		gbc_lblFichierDeSortie.insets = new Insets(0, 0, 5, 5);
		gbc_lblFichierDeSortie.gridx = 1;
		gbc_lblFichierDeSortie.gridy = 6;
		frmGnrationDeScript.getContentPane().add(lblFichierDeSortie, gbc_lblFichierDeSortie);
	    		
	    				output_jmx_file_path_textfield = new JTextField();
	    				output_jmx_file_path_textfield.setColumns(10);
	    				GridBagConstraints gbc_output_jmx_file_path_textfield = new GridBagConstraints();
	    				gbc_output_jmx_file_path_textfield.fill = GridBagConstraints.BOTH;
	    				gbc_output_jmx_file_path_textfield.insets = new Insets(0, 0, 5, 5);
	    				gbc_output_jmx_file_path_textfield.gridwidth = 5;
	    				gbc_output_jmx_file_path_textfield.gridx = 4;
	    				gbc_output_jmx_file_path_textfield.gridy = 6;
	    				frmGnrationDeScript.getContentPane().add(output_jmx_file_path_textfield, gbc_output_jmx_file_path_textfield);
	    		
	    			JButton button_2 = new JButton("...");
	    			button_2.addActionListener(new ActionListener() {
	    				public void actionPerformed(ActionEvent arg0) {
	    					final JFileChooser fc = new JFileChooser();
	    					File f = new File(output_jmx_file_path_textfield.getText());
	    					fc.setCurrentDirectory(f.getParentFile());
	    					FileNameExtensionFilter filter = new FileNameExtensionFilter("JMeter File", "jmx");
	    					fc.setFileFilter(filter);
	    					int returnVal = fc.showOpenDialog(frmGnrationDeScript);
	    					if (returnVal == JFileChooser.APPROVE_OPTION) {
	    						File file = fc.getSelectedFile();
	    						output_jmx_file_path_textfield.setText(file.getPath());
	    					}
	    				}
	    			});
	    			GridBagConstraints gbc_button_2 = new GridBagConstraints();
	    			gbc_button_2.anchor = GridBagConstraints.WEST;
	    			gbc_button_2.insets = new Insets(0, 0, 5, 5);
	    			gbc_button_2.gridx = 9;
	    			gbc_button_2.gridy = 6;
	    			frmGnrationDeScript.getContentPane().add(button_2, gbc_button_2);
	    		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
	    		gbc_btnNewButton.fill = GridBagConstraints.BOTH;
	    		gbc_btnNewButton.gridheight = 2;
	    		gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
	    		gbc_btnNewButton.gridwidth = 3;
	    		gbc_btnNewButton.gridx = 4;
	    		gbc_btnNewButton.gridy = 7;
	    		frmGnrationDeScript.getContentPane().add(btnNewButton, gbc_btnNewButton);
	    	    
	    resultTextArea = new TextArea(5,40);
	    resultTextArea.setEditable(false);
	    
	    	    GridBagConstraints gbc_resultTextArea = new GridBagConstraints();
	    	    gbc_resultTextArea.fill = GridBagConstraints.BOTH;
	    	    gbc_resultTextArea.insets = new Insets(0, 0, 5, 5);
	    	    gbc_resultTextArea.gridwidth = 10;
	    	    gbc_resultTextArea.gridx = 1;
	    	    gbc_resultTextArea.gridy = 9;
	    	    frmGnrationDeScript.getContentPane().add(resultTextArea, gbc_resultTextArea);
	
	}

	public int generate(String scripts , String in, String out, String load, boolean noGUI) {

		File f_out = new File(out);
		File d_git = new File(in);
		
		if (f_out.exists()) {
			if (noGUI) {
				// On ecrase le fichier en mode batch
				logger.info("Existing file, delete it...");
				f_out.delete();
			} else {
				int choice = JOptionPane.showOptionDialog(frmGnrationDeScript,
						"Le fichier existe d�j�, voulez-vous continuer?", "Attention", JOptionPane.YES_NO_OPTION,
						JOptionPane.QUESTION_MESSAGE, null, null, null);
				if (choice == JOptionPane.NO_OPTION) {
					return -1;
				}
			}
		}
		if (!d_git.isDirectory()) {
			if (noGUI) {
				logger.error("repertoire contenant les fichiers JSON incorrect");
				return -1;
			} else {

				JOptionPane.showOptionDialog(frmGnrationDeScript, "Saisir un repertoire GIT existant", "Attention",
						JOptionPane.WARNING_MESSAGE, JOptionPane.CLOSED_OPTION, null, null, null);
				return -1;
			}
		}
		int codeRet = 0;
		JMeterBench bench = engine.generate(scripts , in, out, load);
		if (bench.isHasValidationError()) {
			codeRet = -1;
		}
		if (!noGUI) {
			if (bench.isHasValidationError()) {
				JOptionPane.showMessageDialog(frmGnrationDeScript,
						"Error : see log in %USERPROFILE%/JMeter/generator-jmeter.log file for full log detail");
			} else {
				JOptionPane.showMessageDialog(frmGnrationDeScript, "G�n�ration termin�e");		
			}
			resultTextArea.setText(bench.getMessage());
		}
		return codeRet;
	}
}