package fx_GetOTM.model;


//import java.time.LocalDate;
//import javafx.beans.property.ObjectProperty;
//import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * Classe modele pour la liste des Officiels.
 *
 * @author Pierre VILLAIN
 */

public class ListeOfficiels {
	// haut
	private  StringProperty inDirValue;
	private  StringProperty outFileValue;
	// bas
    private final StringProperty nom;
    private final StringProperty prenom;
    private final StringProperty statut;
    private final StringProperty datematch5;
   
   /**
    * Default constructor.
    */
   public ListeOfficiels() {
       this(null, null, null, null);
   }
   
   /**
    * Constructor with some initial data.
    * 
    * @param nom
    * @param prenom
    * @param statut
    * @param datematch5
    */
   public ListeOfficiels(String nom, String prenom, String statut, String datematch5) {
	   this.inDirValue=new SimpleStringProperty("");
	   this.outFileValue=new SimpleStringProperty("");
	   
       this.nom = new SimpleStringProperty(nom);
       this.prenom = new SimpleStringProperty(prenom);
       this.statut = new SimpleStringProperty(statut);
       this.datematch5 = new SimpleStringProperty(datematch5);
   }

   /** getter **/
   	public String getInDirValue() {
   		return inDirValue.get();
   	}
   	public String getOutFileValue() {
   		return outFileValue.get();
   	}
   	public String getNom() {
   		return nom.get();
   	}
   	public String getPrenom() {
   		return prenom.get();
   	}
   	public String getStatut() {
   		return statut.get();
   	}
   	public String getDatematch5() {
   		return datematch5.get();
   	}
    /** setter **/
   	public void setInDirValue(String data) {
   		this.inDirValue.set(data);
   	}
   	public void setOutFileValue(String data) {
   		this.outFileValue.set(data);
   	}
   	public void setNom(String data) {
   		this.nom.set(data);
   	}
   	public void setPrenom(String data) {
   		this.prenom.set(data);
   	}
   	public void setStatut(String data) {
   		this.statut.set(data);
   	}
   	public void setDatematch5(String data) {
   		this.datematch5.set(data);
   	}
    /** fx properties object **/
	public StringProperty inDirValueProperty() {
		return inDirValue;
	}
	public StringProperty outFileValueProperty() {
		return outFileValue;
	}
	public StringProperty nomProperty() {
		return nom;
	}
	public StringProperty prenomProperty() {
		return prenom;
	}
	public StringProperty statutProperty() {
		return statut;
	}
	public StringProperty datematch5Property() {
		return datematch5;
	}
}
