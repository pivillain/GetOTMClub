package fx_GetOTM.view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import fx_GetOTM.Officiel;
import fx_GetOTM.ListeOTMClub;
import fx_GetOTM.fxGetOTM_main;
import fx_GetOTM.model.ListeOfficiels;

public class ListeOfficielsOverviewController {

	//partie haute de l'affichage
    @FXML
    private Label inDirLabel;
    @FXML
    private TextField inDirValue;
    @FXML
    private Button inDirBtn;
    @FXML
    private Label outFileLabel;
    @FXML
    private TextField outFileValue;
    @FXML
    private Button outFileBtn;
    @FXML
    private Button runBtn;
    //Partie basse tableview
    @FXML
    private TableView<ListeOfficiels> ListeOfficielsTable;
    @FXML
    private TableColumn<ListeOfficiels, String> NomColumn;
    @FXML
    private TableColumn<ListeOfficiels, String> PrenomColumn;
    @FXML
    private TableColumn<ListeOfficiels, String> StatutColumn;
    @FXML
    private TableColumn<ListeOfficiels, String> DateMatch5Column;
    
    
    // Reference to the main application.
    private fxGetOTM_main fxGetOTM_main;
   
    /**
     * The constructor.
     * The constructor is called before the initialize() method.
     */
    public ListeOfficielsOverviewController() {
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
    	// valeurs par d�faut inDir et outFile
    	inDirValue.setText("C:\\temp\\GetOTMClub\\data");
    	outFileValue.setText("C:\\temp\\GetOTMClub\\OTMClub.csv");
        // Initialize the listeOfficiels table.
    	NomColumn.setCellValueFactory(cellData -> cellData.getValue().nomProperty());
    	PrenomColumn.setCellValueFactory(cellData -> cellData.getValue().prenomProperty());
    	StatutColumn.setCellValueFactory(cellData -> cellData.getValue().statutProperty());
    	DateMatch5Column.setCellValueFactory(cellData -> cellData.getValue().datematch5Property());    	
    }
    
    @FXML
    public void dirChooser() {
    	final DirectoryChooser searchDir = new DirectoryChooser();
    	
    	ListeOfficiels lso = new ListeOfficiels();

    	System.out.println("valeur saisie : " + inDirValue.getText());

    	if (inDirValue.getText() != null) {
    		searchDir.setInitialDirectory(new File(inDirValue.getText()));
    	}
    	File selectedDirectory = searchDir.showDialog(fxGetOTM_main.getPrimaryStage());
    	if (selectedDirectory != null) {
    		System.out.println("choix : "+selectedDirectory);
    		inDirValue.setText(selectedDirectory.getAbsolutePath());
    	}
    }
	@SuppressWarnings("static-access")
	@FXML
    public void outChooser() {
    	final DirectoryChooser fileChooser = new DirectoryChooser();

		if (outFileValue.getText() != null) {
    		File initDir=new File(outFileValue.getText());
    		if (! initDir.canRead()) {initDir=new File(System.getProperty("user.home"));}
			fileChooser.setInitialDirectory(initDir);
    	}
		final File selectedFile = fileChooser.showDialog(fxGetOTM_main.getPrimaryStage());
    	if (selectedFile != null) {
    		System.out.println("choix : "+selectedFile);
    		outFileValue.setText(selectedFile.getAbsolutePath()+"/OTMClub.csv");
    	}
    }
	
	public void chercheOTM() throws IOException {
		ObservableList<ListeOfficiels> affichelisteOfficiels = FXCollections.observableArrayList();
		affichelisteOfficiels=ListeOTMClub.ListeOTMClub_run(inDirValue.getText(), outFileValue.getText());
		ListeOfficielsTable.setItems(affichelisteOfficiels);
	}
    /**
     * Is called by the main application to give a reference back to itself.
     * 
     * @param fxGetOTM_main
     */
    public void setfxGetOTM_main(fxGetOTM_main fxGetOTM_main) {
        this.fxGetOTM_main = fxGetOTM_main;

        // Add observable list data to the table
        ListeOfficielsTable.setItems(fxGetOTM_main.getListeOfficielsData());
    }
}

